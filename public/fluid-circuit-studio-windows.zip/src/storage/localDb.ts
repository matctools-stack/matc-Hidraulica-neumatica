import { PRESET_PROJECTS } from '../data/presets';
import { createOfflineUserRecord } from '../security/offlineAuth';
import type {
  AuditLogEntry,
  AuthSession,
  CircuitProject,
  OfflineUser,
} from '../types/circuit';

const DB_NAME = 'fluid_circuit_studio_db';
const DB_VERSION = 1;

const STORE_PROJECTS = 'projects';
const STORE_USERS = 'users';
const STORE_AUDIT = 'auditLogs';
const STORE_META = 'meta';

const SESSION_KEY = 'fcs_offline_session_v1';
const LICENSE_KEY = 'fcs_offline_license_v1';
const DRAFT_KEY = 'fcs_autosave_draft_v1';

interface ElectronDesktopBridge {
  isElectron: boolean;
  platform: string;
  appVersion: string;
  syncVault?: (payload: {
    projects: CircuitProject[];
    auditLogs: AuditLogEntry[];
  }) => Promise<boolean>;
  exportProjectFile?: (filename: string, content: string) => Promise<boolean>;
}

declare global {
  interface Window {
    fluidDesktop?: ElectronDesktopBridge;
  }
}

export function isElectronRuntime(): boolean {
  return typeof window !== 'undefined' && Boolean(window.fluidDesktop?.isElectron);
}

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB indisponível neste ambiente.'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
        db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_USERS)) {
        db.createObjectStore(STORE_USERS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_AUDIT)) {
        db.createObjectStore(STORE_AUDIT, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Falha ao abrir IndexedDB.'));
  });
}

async function getAllFromStore<T>(storeName: string): Promise<T[]> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve((req.result as T[]) ?? []);
    req.onerror = () => reject(req.error);
  });
}

async function putInStore<T>(storeName: string, value: T): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.put(value);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

async function deleteFromStore(storeName: string, key: string): Promise<void> {
  const db = await openDatabase();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    store.delete(key);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

let seedPromise: Promise<void> | null = null;

export async function ensureLocalDatabaseSeeded(): Promise<void> {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    const existingUsers = await getAllFromStore<OfflineUser>(STORE_USERS);
    if (existingUsers.length === 0) {
      const admin = await createOfflineUserRecord({
        id: 'usr_admin_default',
        username: 'admin',
        displayName: 'Administrador Local',
        role: 'admin',
        password: 'fluid2026',
      });
      const engineer = await createOfflineUserRecord({
        id: 'usr_eng_default',
        username: 'engenheiro',
        displayName: 'Eng. Hidráulico',
        role: 'engineer',
        password: 'eng2026',
      });
      const operator = await createOfflineUserRecord({
        id: 'usr_op_default',
        username: 'operador',
        displayName: 'Operador Bancada',
        role: 'operator',
        password: 'op2026',
      });
      await putInStore(STORE_USERS, admin);
      await putInStore(STORE_USERS, engineer);
      await putInStore(STORE_USERS, operator);
    }

    const existingProjects = await getAllFromStore<CircuitProject>(STORE_PROJECTS);
    if (existingProjects.length === 0) {
      for (const preset of PRESET_PROJECTS) {
        await putInStore(STORE_PROJECTS, preset);
      }
    }
  })();
  return seedPromise;
}

export async function listProjects(): Promise<CircuitProject[]> {
  await ensureLocalDatabaseSeeded();
  const list = await getAllFromStore<CircuitProject>(STORE_PROJECTS);
  return list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function saveProject(project: CircuitProject): Promise<CircuitProject> {
  await ensureLocalDatabaseSeeded();
  const updated: CircuitProject = {
    ...project,
    updatedAt: new Date().toISOString(),
  };
  await putInStore(STORE_PROJECTS, updated);
  await syncElectronVaultIfAvailable();
  return updated;
}

export async function removeProject(projectId: string): Promise<void> {
  await deleteFromStore(STORE_PROJECTS, projectId);
  await syncElectronVaultIfAvailable();
}

export async function listUsers(): Promise<OfflineUser[]> {
  await ensureLocalDatabaseSeeded();
  const users = await getAllFromStore<OfflineUser>(STORE_USERS);
  return users.sort((a, b) => a.username.localeCompare(b.username));
}

export async function saveUser(user: OfflineUser): Promise<void> {
  await putInStore(STORE_USERS, user);
}

export async function findUserByUsername(
  username: string
): Promise<OfflineUser | undefined> {
  const users = await listUsers();
  const norm = username.trim().toLowerCase();
  return users.find((u) => u.username === norm);
}

export async function listAuditLogs(): Promise<AuditLogEntry[]> {
  const logs = await getAllFromStore<AuditLogEntry>(STORE_AUDIT);
  return logs.sort((a, b) => b.timestamp.localeCompare(a.timestamp)).slice(0, 120);
}

export async function appendAuditLog(
  entry: Omit<AuditLogEntry, 'id' | 'timestamp'>
): Promise<void> {
  const full: AuditLogEntry = {
    ...entry,
    id: `log_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
  };
  await putInStore(STORE_AUDIT, full);
  await syncElectronVaultIfAvailable();
}

async function syncElectronVaultIfAvailable(): Promise<void> {
  if (!window.fluidDesktop?.syncVault) return;
  try {
    const [projects, auditLogs] = await Promise.all([
      getAllFromStore<CircuitProject>(STORE_PROJECTS),
      getAllFromStore<AuditLogEntry>(STORE_AUDIT),
    ]);
    await window.fluidDesktop.syncVault({ projects, auditLogs });
  } catch {
    // Non-blocking desktop mirror sync
  }
}

export function loadStoredSession(): AuthSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AuthSession;
  } catch {
    return null;
  }
}

export function saveStoredSession(session: AuthSession | null): void {
  try {
    if (!session) {
      localStorage.removeItem(SESSION_KEY);
    } else {
      localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    }
  } catch {
    // Ignore storage quota exceptions
  }
}

export function loadLicenseTier(): 'Community Offline' | 'Industrial Pro' {
  return 'Industrial Pro';
}

export function saveLicenseTier(tier: 'Community Offline' | 'Industrial Pro'): void {
  try {
    localStorage.setItem(LICENSE_KEY, tier);
  } catch {
    // Ignore
  }
}

export function saveAutosaveDraft(project: CircuitProject): void {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify(project));
  } catch {
    // Ignore
  }
}

export function loadAutosaveDraft(): CircuitProject | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as CircuitProject;
  } catch {
    return null;
  }
}
