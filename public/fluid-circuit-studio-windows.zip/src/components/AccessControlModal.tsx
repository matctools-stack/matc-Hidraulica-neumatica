import React, { useEffect, useState } from 'react';
import { Check, Copy, KeyRound, RefreshCw, ShieldCheck, UserPlus, X } from 'lucide-react';
import {
  createOfflineUserRecord,
  generateAccessKey,
  getRolePermissions,
} from '../security/offlineAuth';
import {
  appendAuditLog,
  listAuditLogs,
  listUsers,
  saveUser,
} from '../storage/localDb';
import type { AuditLogEntry, AuthSession, OfflineUser, UserRole } from '../types/circuit';

interface AccessControlModalProps {
  open: boolean;
  session: AuthSession;
  onClose: () => void;
  onLicenseUpdated?: (tier: 'Community Offline' | 'Industrial Pro') => void;
}

function getRoleDisplayLabel(role: UserRole): string {
  switch (role) {
    case 'admin':
      return 'Administrador';
    case 'engineer':
      return 'Professor';
    case 'operator':
      return 'Aluno';
  }
}

export const AccessControlModal: React.FC<AccessControlModalProps> = ({
  open,
  session,
  onClose,
}) => {
  const [users, setUsers] = useState<OfflineUser[]>([]);
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [newUsername, setNewUsername] = useState('');
  const [newDisplayName, setNewDisplayName] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('operator');
  const [newPassword, setNewPassword] = useState(() => generateAccessKey('operator'));
  const [issuedInvite, setIssuedInvite] = useState<{
    username: string;
    displayName: string;
    role: UserRole;
    accessKey: string;
  } | null>(null);
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const perms = getRolePermissions(session.role);

  const refreshData = async () => {
    const [u, l] = await Promise.all([listUsers(), listAuditLogs()]);
    setUsers(u);
    setLogs(l);
  };

  useEffect(() => {
    if (open) {
      refreshData();
      setFeedback(null);
      setErrorMsg(null);
      setCopiedInvite(false);
    }
  }, [open]);

  if (!open) return null;

  const handleRoleChange = (role: UserRole) => {
    setNewRole(role);
    setNewPassword(generateAccessKey(role));
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setFeedback(null);
    setCopiedInvite(false);

    const clean = newUsername.trim().toLowerCase();
    const keyVal = newPassword.trim();
    if (!clean || !newDisplayName.trim() || keyVal.length < 4) {
      setErrorMsg('Preencha usuário, nome completo e chave de acesso (mínimo 4 caracteres).');
      return;
    }
    if (users.some((u) => u.username === clean)) {
      setErrorMsg('Este usuário já existe.');
      return;
    }

    const record = await createOfflineUserRecord({
      username: clean,
      displayName: newDisplayName.trim(),
      role: newRole,
      password: keyVal,
    });
    await saveUser(record);
    await appendAuditLog({
      userId: session.userId,
      username: session.username,
      action: 'USER_CREATED',
      detail: `Chave de acesso emitida para ${getRoleDisplayLabel(record.role)}: ${record.username}.`,
    });
    setIssuedInvite({
      username: record.username,
      displayName: record.displayName,
      role: record.role,
      accessKey: keyVal,
    });
    setNewUsername('');
    setNewDisplayName('');
    setNewPassword(generateAccessKey(newRole));
    setFeedback(`Conta "${record.username}" (${getRoleDisplayLabel(record.role)}) ativada com chave de acesso.`);
    await refreshData();
  };

  const handleRegenerateKey = async (target: OfflineUser) => {
    setErrorMsg(null);
    setFeedback(null);
    setCopiedInvite(false);
    const nextKey = generateAccessKey(target.role);
    const updated = await createOfflineUserRecord({
      id: target.id,
      username: target.username,
      displayName: target.displayName,
      role: target.role,
      password: nextKey,
    });
    updated.active = target.active;
    updated.createdAt = target.createdAt;
    updated.lastLoginAt = target.lastLoginAt;
    await saveUser(updated);
    await appendAuditLog({
      userId: session.userId,
      username: session.username,
      action: 'USER_TOGGLED',
      detail: `Nova chave de acesso gerada para ${target.username} (${getRoleDisplayLabel(target.role)}).`,
    });
    setIssuedInvite({
      username: target.username,
      displayName: target.displayName,
      role: target.role,
      accessKey: nextKey,
    });
    setFeedback(`Nova chave de acesso gerada para "${target.username}".`);
    await refreshData();
  };

  const handleCopyInvite = async () => {
    if (!issuedInvite) return;
    const text = `Fluid Circuit Studio - Acesso (${getRoleDisplayLabel(issuedInvite.role)})\nUsuário: ${issuedInvite.username}\nChave de Acesso: ${issuedInvite.accessKey}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedInvite(true);
      window.setTimeout(() => setCopiedInvite(false), 2500);
    } catch {
      setFeedback(text);
    }
  };

  const handleToggleUser = async (target: OfflineUser) => {
    if (target.id === session.userId) {
      setErrorMsg('Não é possível bloquear o próprio administrador conectado.');
      return;
    }
    const updated = { ...target, active: !target.active };
    await saveUser(updated);
    await appendAuditLog({
      userId: session.userId,
      username: session.username,
      action: 'USER_TOGGLED',
      detail: `Usuário ${target.username} ${updated.active ? 'ativado' : 'bloqueado'}.`,
    });
    await refreshData();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="access-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4"
    >
      <div className="w-full max-w-4xl max-h-[88vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-sky-600 dark:text-sky-400" />
            <div>
              <h2 id="access-modal-title" className="text-base font-semibold text-slate-900 dark:text-white">
                {perms.canManageUsers
                  ? 'Configurações do Administrador e Chaves de Acesso'
                  : 'Auditoria e Sessão'}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Sessão: {session.displayName} ({getRoleDisplayLabel(session.role)}) · Aplicativo Ativo
                {perms.canManageUsers ? ' · Criptografia PBKDF2-SHA256' : ''}
              </p>
            </div>
          </div>
          <button
            type="button"
            aria-label="Fechar controle de acesso"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {errorMsg && (
            <div role="alert" className="p-3 rounded-lg bg-red-50 dark:bg-red-950/40 text-xs text-red-700 dark:text-red-300">
              {errorMsg}
            </div>
          )}
          {feedback && (
            <div role="status" className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-xs text-emerald-700 dark:text-emerald-300">
              {feedback}
            </div>
          )}

          {/* Ready-to-send Access Key Card */}
          {issuedInvite && (
            <div className="p-4 rounded-lg border border-sky-300 dark:border-sky-800 bg-sky-50/80 dark:bg-sky-950/40 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1 text-xs">
                <div className="flex items-center gap-1.5 font-semibold text-sky-800 dark:text-sky-300">
                  <KeyRound className="w-4 h-4" />
                  Chave de Acesso Pronta para Enviar ({getRoleDisplayLabel(issuedInvite.role)})
                </div>
                <div className="font-mono text-slate-800 dark:text-slate-100">
                  Usuário: <strong>{issuedInvite.username}</strong> · Chave:{' '}
                  <strong data-testid="issued-access-key">{issuedInvite.accessKey}</strong>
                </div>
              </div>
              <button
                type="button"
                onClick={handleCopyInvite}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-sky-600 hover:bg-sky-700 text-white text-xs font-medium shrink-0"
              >
                {copiedInvite ? (
                  <>
                    <Check className="w-3.5 h-3.5" /> Chave Copiada
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" /> Copiar para Enviar
                  </>
                )}
              </button>
            </div>
          )}

          {/* Local Users Management */}
          {perms.canManageUsers ? (
            <div className="space-y-4">
              <form
                onSubmit={handleCreateUser}
                className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 space-y-3"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-slate-900 dark:text-white">
                    <UserPlus className="w-4 h-4 text-sky-600" />
                    Criar e Enviar Chave de Acesso — Aluno / Professor (PBKDF2-SHA256)
                  </div>
                  <button
                    type="button"
                    onClick={() => setNewPassword(generateAccessKey(newRole))}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-300 dark:border-slate-700 text-[11px] font-medium hover:bg-slate-100 dark:hover:bg-slate-800"
                  >
                    <RefreshCw className="w-3 h-3" /> Gerar Chave
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-2.5">
                  <input
                    type="text"
                    aria-label="Nome de usuário"
                    placeholder="Usuário (ex: aluno01)"
                    value={newUsername}
                    onChange={(e) => setNewUsername(e.target.value)}
                    className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                  />
                  <input
                    type="text"
                    aria-label="Nome de exibição"
                    placeholder="Nome Completo"
                    value={newDisplayName}
                    onChange={(e) => setNewDisplayName(e.target.value)}
                    className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                  />
                  <select
                    aria-label="Perfil de permissão"
                    value={newRole}
                    onChange={(e) => handleRoleChange(e.target.value as UserRole)}
                    className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs"
                  >
                    <option value="operator">Aluno (Simular/Visualizar)</option>
                    <option value="engineer">Professor (Editar/Salvar)</option>
                    <option value="admin">Administrador (Total)</option>
                  </select>
                  <input
                    type="text"
                    aria-label="Chave de acesso"
                    placeholder="Chave de Acesso"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="px-3 py-1.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-mono"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 rounded-md bg-sky-600 hover:bg-sky-700 text-white text-xs font-medium"
                >
                  Ativar e Gerar Chave de Acesso
                </button>
              </form>

              <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500">
                    <tr>
                      <th className="px-3 py-2 font-medium">Usuário</th>
                      <th className="px-3 py-2 font-medium">Nome</th>
                      <th className="px-3 py-2 font-medium">Perfil</th>
                      <th className="px-3 py-2 font-medium">Status</th>
                      <th className="px-3 py-2 font-medium text-right">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {users.map((u) => (
                      <tr key={u.id}>
                        <td className="px-3 py-2 font-mono">{u.username}</td>
                        <td className="px-3 py-2">{u.displayName}</td>
                        <td className="px-3 py-2">{getRoleDisplayLabel(u.role)}</td>
                        <td className="px-3 py-2">
                          <span className={u.active ? 'text-emerald-600' : 'text-red-500'}>
                            {u.active ? 'Ativo' : 'Bloqueado'}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right space-x-1.5">
                          <button
                            type="button"
                            onClick={() => handleRegenerateKey(u)}
                            className="px-2 py-1 rounded border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 hover:bg-sky-50 dark:hover:bg-sky-950 text-[11px]"
                          >
                            Nova Chave
                          </button>
                          <button
                            type="button"
                            onClick={() => handleToggleUser(u)}
                            className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-[11px]"
                          >
                            {u.active ? 'Bloquear' : 'Reativar'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs text-slate-500">
              O gerenciamento e envio de chaves de acesso para Alunos e Professores é exclusivo do Administrador.
            </div>
          )}

          {/* Local Audit Logs */}
          {perms.canViewAuditLog && (
            <div>
              <h3 className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
                Registro Local de Auditoria ({logs.length})
              </h3>
              <div className="max-h-48 overflow-y-auto border border-slate-200 dark:border-slate-800 rounded-lg divide-y divide-slate-200 dark:divide-slate-800 text-xs">
                {logs.map((entry) => (
                  <div key={entry.id} className="px-3 py-2 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <span className="font-mono font-medium text-slate-900 dark:text-white">
                        {entry.action}
                      </span>{' '}
                      <span className="text-slate-500">· {entry.username} ·</span>{' '}
                      <span className="text-slate-700 dark:text-slate-300">{entry.detail}</span>
                    </div>
                    <span className="font-mono text-[11px] text-slate-400">
                      {new Date(entry.timestamp).toLocaleString('pt-BR')}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

