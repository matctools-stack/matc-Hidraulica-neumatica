export const WINDOWS_PACKAGE_ZIP_BASE64 = "";
