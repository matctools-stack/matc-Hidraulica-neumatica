import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildAuthSession,
  createOfflineUserRecord,
  generateAccessKey,
  generateSampleProLicenseKey,
  getRolePermissions,
  isSessionExpired,
  validateOfflineLicenseKey,
  verifyPasswordPBKDF2,
} from './offlineAuth';

test('PBKDF2 password hashing verifies valid credentials and rejects wrong passwords', async () => {
  const user = await createOfflineUserRecord({
    username: 'eng_marcos',
    displayName: 'Marcos Silva',
    role: 'engineer',
    password: 'fluid-secret-password',
  });

  assert.equal(
    await verifyPasswordPBKDF2('fluid-secret-password', user.saltHex, user.passwordHashHex),
    true
  );
  assert.equal(
    await verifyPasswordPBKDF2('wrong-password', user.saltHex, user.passwordHashHex),
    false
  );
});

test('Role permission matrix restricts operator from editing or user management', () => {
  const admin = getRolePermissions('admin');
  const engineer = getRolePermissions('engineer');
  const operator = getRolePermissions('operator');

  assert.equal(admin.canManageUsers, true);
  assert.equal(engineer.canManageUsers, false);
  assert.equal(engineer.canEditCircuit, true);
  assert.equal(operator.canEditCircuit, false);
  assert.equal(operator.canRunSimulation, true);
});

test('Offline license key generator & validator round-trip cleanly', () => {
  const key = generateSampleProLicenseKey('IND2026X');
  const ok = validateOfflineLicenseKey(key);
  assert.equal(ok.valid, true);
  assert.equal(ok.tier, 'Industrial Pro');

  const bad = validateOfflineLicenseKey('FCS-PRO-IND2-026X-00');
  assert.equal(bad.valid, false);
});

test('Offline session expiry check respects TTL', async () => {
  const user = await createOfflineUserRecord({
    username: 'op1',
    displayName: 'Operador',
    role: 'operator',
    password: '123',
  });
  const activeSession = buildAuthSession(user, 'Community Offline', 12);
  assert.equal(isSessionExpired(activeSession), false);

  const expiredSession = buildAuthSession(user, 'Community Offline', -1);
  assert.equal(isSessionExpired(expiredSession), true);
});

test('generateAccessKey creates formatted access keys for Aluno, Professor, and Admin', () => {
  const alunoKey = generateAccessKey('operator');
  const profKey = generateAccessKey('engineer');
  const adminKey = generateAccessKey('admin');

  assert.match(alunoKey, /^FCS-ALUNO-[A-Z0-9]{6}$/);
  assert.match(profKey, /^FCS-PROF-[A-Z0-9]{6}$/);
  assert.match(adminKey, /^FCS-ADMIN-[A-Z0-9]{6}$/);
});

