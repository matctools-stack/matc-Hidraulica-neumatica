import type { AuthSession, OfflineUser, UserRole } from '../types/circuit';

const PBKDF2_ITERATIONS = 100_000;

function toHex(bytes: Uint8Array): string {
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function fromHex(hex: string): Uint8Array {
  const clean = hex.trim();
  const out = new Uint8Array(clean.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

export function generateSaltHex(lengthBytes = 16): string {
  const buf = new Uint8Array(lengthBytes);
  globalThis.crypto.getRandomValues(buf);
  return toHex(buf);
}

export async function hashPasswordPBKDF2(
  password: string,
  saltHex: string
): Promise<string> {
  const enc = new TextEncoder();
  const keyMaterial = await globalThis.crypto.subtle.importKey(
    'raw',
    enc.encode(password),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const saltBytes = fromHex(saltHex);
  const bits = await globalThis.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes.buffer as ArrayBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    256
  );
  return toHex(new Uint8Array(bits));
}

export async function verifyPasswordPBKDF2(
  password: string,
  saltHex: string,
  expectedHashHex: string
): Promise<boolean> {
  const computed = await hashPasswordPBKDF2(password, saltHex);
  if (computed.length !== expectedHashHex.length) return false;
  let diff = 0;
  for (let i = 0; i < computed.length; i++) {
    diff |= computed.charCodeAt(i) ^ expectedHashHex.charCodeAt(i);
  }
  return diff === 0;
}

export async function createOfflineUserRecord(params: {
  id?: string;
  username: string;
  displayName: string;
  role: UserRole;
  password: string;
}): Promise<OfflineUser> {
  const saltHex = generateSaltHex(16);
  const passwordHashHex = await hashPasswordPBKDF2(params.password, saltHex);
  return {
    id: params.id ?? `usr_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    username: params.username.trim().toLowerCase(),
    displayName: params.displayName.trim(),
    role: params.role,
    saltHex,
    passwordHashHex,
    active: true,
    createdAt: new Date().toISOString(),
  };
}

export interface RolePermissions {
  canEditCircuit: boolean;
  canRunSimulation: boolean;
  canSaveProjects: boolean;
  canDeleteProjects: boolean;
  canExportFiles: boolean;
  canManageUsers: boolean;
  canViewAuditLog: boolean;
}

export function getRolePermissions(role: UserRole): RolePermissions {
  switch (role) {
    case 'admin':
      return {
        canEditCircuit: true,
        canRunSimulation: true,
        canSaveProjects: true,
        canDeleteProjects: true,
        canExportFiles: true,
        canManageUsers: true,
        canViewAuditLog: true,
      };
    case 'engineer':
      return {
        canEditCircuit: true,
        canRunSimulation: true,
        canSaveProjects: true,
        canDeleteProjects: true,
        canExportFiles: true,
        canManageUsers: false,
        canViewAuditLog: true,
      };
    case 'operator':
      return {
        canEditCircuit: false,
        canRunSimulation: true,
        canSaveProjects: false,
        canDeleteProjects: false,
        canExportFiles: true,
        canManageUsers: false,
        canViewAuditLog: false,
      };
  }
}

/**
 * Validates deterministic offline license key format: FCS-PRO-XXXX-XXXX-CC
 * where CC is a 2-hex-digit XOR/sum checksum of the preceding characters.
 */
export function validateOfflineLicenseKey(rawKey: string): {
  valid: boolean;
  tier: 'Community Offline' | 'Industrial Pro';
  reason?: string;
} {
  const key = rawKey.trim().toUpperCase();
  if (!key) {
    return { valid: false, tier: 'Community Offline', reason: 'Chave vazia.' };
  }
  const match = /^FCS-PRO-([A-Z0-9]{4})-([A-Z0-9]{4})-([0-9A-F]{2})$/.exec(key);
  if (!match) {
    return {
      valid: false,
      tier: 'Community Offline',
      reason: 'Formato esperado: FCS-PRO-XXXX-XXXX-CC',
    };
  }
  const payload = `${match[1]}${match[2]}`;
  let sum = 0x5a;
  for (let i = 0; i < payload.length; i++) {
    sum = (sum + payload.charCodeAt(i) * (i + 3)) & 0xff;
  }
  const expectedChecksum = sum.toString(16).padStart(2, '0').toUpperCase();
  if (match[3] !== expectedChecksum) {
    return {
      valid: false,
      tier: 'Community Offline',
      reason: 'Assinatura offline inválida.',
    };
  }
  return { valid: true, tier: 'Industrial Pro' };
}

export function generateSampleProLicenseKey(seed = 'LAB2026A'): string {
  const clean = seed.toUpperCase().replace(/[^A-Z0-9]/g, '').padEnd(8, 'X').slice(0, 8);
  const seg1 = clean.slice(0, 4);
  const seg2 = clean.slice(4, 8);
  let sum = 0x5a;
  for (let i = 0; i < clean.length; i++) {
    sum = (sum + clean.charCodeAt(i) * (i + 3)) & 0xff;
  }
  const checksum = sum.toString(16).padStart(2, '0').toUpperCase();
  return `FCS-PRO-${seg1}-${seg2}-${checksum}`;
}

export function buildAuthSession(
  user: OfflineUser,
  licenseTier: 'Community Offline' | 'Industrial Pro' = 'Community Offline',
  ttlHours = 24
): AuthSession {
  const now = new Date();
  const expires = new Date(now.getTime() + ttlHours * 3600 * 1000);
  return {
    userId: user.id,
    username: user.username,
    displayName: user.displayName,
    role: user.role,
    signedInAt: now.toISOString(),
    expiresAt: expires.toISOString(),
    offlineToken: `off_${generateSaltHex(12)}`,
    licenseTier,
  };
}

export function isSessionExpired(session: AuthSession | null): boolean {
  if (!session) return true;
  return new Date(session.expiresAt).getTime() <= Date.now();
}

export function generateAccessKey(role: UserRole): string {
  const prefix = role === 'operator' ? 'ALUNO' : role === 'engineer' ? 'PROF' : 'ADMIN';
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const buf = new Uint8Array(6);
  globalThis.crypto.getRandomValues(buf);
  let code = '';
  for (let i = 0; i < buf.length; i += 1) {
    code += alphabet[buf[i] % alphabet.length];
  }
  return `FCS-${prefix}-${code}`;
}

